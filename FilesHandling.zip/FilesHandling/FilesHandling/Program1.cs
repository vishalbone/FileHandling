﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesHandling
{
    class Program1
    {
        static void Main(string[] args)
        {
            string filename = @"C:\Users\HP\OneDrive\Desktop\Employee.txt";
            string filename1 = @"C:\Users\HP\OneDrive\Desktop\Department.txt";
            string filename2 = @"C:\Users\HP\OneDrive\Desktop\Projects.txt";
            List<Employee> emprec = new List<Employee>();
            List<Depatment> deprec = new List<Depatment>();
            List<Projects> prorec = new List<Projects>();
            int ch;
            
            do
            {
                Console.WriteLine("1 Employee Record");
                Console.WriteLine("2 Depatrment Record");
                Console.WriteLine("3 Project Record");
                Console.WriteLine("4 Display Employee Record");
                Console.WriteLine("5 Display Department Record");
                Console.WriteLine("6 Display project Record");
                Console.WriteLine("7 Insert in to the Employee File");
                Console.WriteLine("8 Insert in to the Department File");
                Console.WriteLine("9 Insert in to the Project File");
                Console.WriteLine("10 Get project Info by Employee ID");
                Console.WriteLine("11 Get Employee Info by Depart ID");
                Console.WriteLine("12 Get Employee Info by Depart Name");
                Console.WriteLine("13 Exit");
                Console.Write("Enter the choice = ");
                ch = int.Parse(Console.ReadLine());

                switch(ch)
                {
                    case 1:
                            Employee emp = new Employee();
                            emprec.Add(emp);
                            break;
                    case 2: Depatment dep = new Depatment();
                            deprec.Add(dep);
                            break;
                    case 3: Projects pro = new Projects();
                            prorec.Add(pro);
                            break;
                    case 4: foreach(Employee e in emprec)
                            {
                                e.display();
                            }
                            break;
                    case 5: foreach (Depatment d in deprec)
                                d.displayDept();
                            break;
                    case 6: foreach (Projects p in prorec)
                                p.display();
                            break;
                    case 7:                           
                            try
                            {
                                using (StreamWriter writer = new StreamWriter(filename,true))
                                {
                                    foreach(Employee e in emprec)
                                    {
                                        writer.Write(e.outputstring() + "\n");
                                    }
                                }
                            }
                            catch(Exception e1)
                            {
                                Console.WriteLine(e1.Message);
                            }
                            break;
                    case 8: 
                            try
                            {
                                using (StreamWriter writer = new StreamWriter(filename1, true))
                                {
                                    foreach (Depatment d in deprec)
                                    {
                                        writer.Write(d.outputstring() + "\n");
                                    }
                                }
                            }
                            catch (Exception e1)
                            {
                                Console.WriteLine(e1.Message);
                            }
                            break;
                    case 9: 
                            try
                            {
                                using (StreamWriter writer = new StreamWriter(filename2, true))
                                {
                                    foreach(Projects p in prorec)
                                    {
                                        writer.Write(p.outputstring() + "\n");
                                    }
                                }
                            }
                            catch(Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            break;
                    case 10: Console.WriteLine("Enter the Empid");
                            string ID = Console.ReadLine();
                            Connectfile.projectbyempID(ID, filename, filename2);
                            break;
                    case 11: Console.WriteLine("Enter the Department ID");
                             string ID1 = Console.ReadLine();
                            Connectfile.EmpInfobyDeptID(ID1, filename, filename1);
                            break;
                    case 12: Console.WriteLine("Enter the Department Name");
                        string name = Console.ReadLine();
                        Connectfile.searchbyDeptname(name, filename, filename1);
                        break;
                    case 13: Console.WriteLine("Successfully loged out"); break;
                    default: Console.WriteLine("Invalid choice");break;
                }

            } while (ch != 13);
        }
    }
}
