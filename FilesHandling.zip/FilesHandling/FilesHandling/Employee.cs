﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesHandling
{
    class Employee
    {
        public int EmpID,DeptId;
        public string EmpName,Email;
        public long Phone;

        public Employee()
        {
            Console.WriteLine("Enter the EmpId");
            EmpID = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the DeptId");
            DeptId = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Employee Name");
            EmpName = Console.ReadLine();

            Console.WriteLine("Enter the Email");
            Email = Console.ReadLine();

            Console.WriteLine("Enter the Phone Number");
            Phone = long.Parse(Console.ReadLine());
        }

        public void display()
        {
            Console.WriteLine(EmpName.PadLeft(10) + " | " + EmpID.ToString().PadLeft(10) + " | " + DeptId.ToString().PadLeft(10) +
                " | " + Email.PadLeft(10) + " | " + Phone.ToString().PadLeft(10));
        }
        public string outputstring()
        {
            return (EmpName.PadLeft(20) + " | " + EmpID.ToString().PadLeft(20) + " | " + DeptId.ToString().PadLeft(20) +
                " | " + Email.PadLeft(20) + " | " + Phone.ToString().PadLeft(20));
        }

    }
}
