﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesHandling
{
    class Depatment
    {
        public int DeptId,NoofProj;
        public string DeptName;

        public Depatment()
        {
            Console.WriteLine("Enter the DeptID");
            DeptId = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Dept Name");
            DeptName = Console.ReadLine();

            Console.WriteLine("Enter the Number of Projects");
            NoofProj = int.Parse(Console.ReadLine());
        }

        public void displayDept()
        {
            Console.WriteLine(DeptId.ToString().PadLeft(10) + " | " + DeptName.PadLeft(10) + " | " + NoofProj.ToString().PadLeft(10));
        }

        public string outputstring()
        {
            return (DeptId.ToString().PadLeft(20) + " | " + DeptName.PadLeft(20) + " | " + NoofProj.ToString().PadLeft(20));
        }
    }
}
