﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesHandling
{
    class Depatment
    {
        public int DeptId,NoofProj;
        public string DeptName;

        public Depatment()
        {
            Console.WriteLine("Enter the DeptID");
            DeptId = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Dept Name");
            DeptName = Console.ReadLine();

            Console.WriteLine("Enter the Number of Projects");
            NoofProj = int.Parse(Console.ReadLine());
        }

        public override string ToString()
        {
            return (DeptId.ToString().PadLeft(20) + " | " + DeptName.PadLeft(20) + " | " + NoofProj.ToString().PadLeft(20) + "\n");
        }

        public bool checkduplicate(string departpath)
        {
            string lines;
            StreamReader ob = new StreamReader(departpath);
            while ((lines = ob.ReadLine()) != null)
            {
                if (lines.Substring(17, 3) == this.DeptId.ToString())
                {
                    ob.Close();
                    return false;
                }
            }
            ob.Close();
            return true;
        }
    }
}
