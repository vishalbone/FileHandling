﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesHandling
{
    class Projects
    {
        public int Pid,MagId;
        public string Pname;

        public Projects()
        {
            Console.WriteLine("Enter the Project ID");
            Pid = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Project Name");
            Pname = Console.ReadLine();

            Console.WriteLine("Enter the Manager Id");
            MagId = int.Parse(Console.ReadLine());
        }
        public override string ToString()
        {
            return (Pid.ToString().PadLeft(20) + " | " + Pname.PadLeft(20) + " | " + MagId.ToString().PadLeft(20) + "\n");
        }

        public bool checkduplicate(string projpath)
        {
            string lines;
            StreamReader reader = new StreamReader(projpath);
            while ((lines = reader.ReadLine()) != null)
            {
                if (lines.Substring(17, 3) == this.Pid.ToString())
                {
                    reader.Close();
                    return false;
                }
            }
            reader.Close();
            return true;
        }
    }
}
