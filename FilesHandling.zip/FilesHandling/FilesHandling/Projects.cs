﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesHandling
{
    class Projects
    {
        public int Pid,MagId;
        public string Pname;

        public Projects()
        {
            Console.WriteLine("Enter the Project ID");
            Pid = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Project Name");
            Pname = Console.ReadLine();

            Console.WriteLine("Enter the Manager Id");
            MagId = int.Parse(Console.ReadLine());
        }

        public void display()
        {
            Console.WriteLine(Pid.ToString().PadLeft(20) + " | " + Pname.PadLeft(20) + " | " + MagId.ToString().PadLeft(20));
        }
        public string outputstring()
        {
            return (Pid.ToString().PadLeft(20) + " | " + Pname.PadLeft(20) + " | " + MagId.ToString().PadLeft(20));
        }
    }
}
